from django.contrib import admin
from aminities_app.models import Aminities

# Register your models here.
admin.site.register(Aminities)