from django.apps import AppConfig


class AminitiesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aminities_app'
