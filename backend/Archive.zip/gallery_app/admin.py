from django.contrib import admin
from gallery_app.models import Gallery
# Register your models here.

admin.site.register(Gallery)