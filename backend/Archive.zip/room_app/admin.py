from django.contrib import admin
from room_app.models import Room
# Register your models here.
admin.site.register(Room)