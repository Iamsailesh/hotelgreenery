from django.contrib import admin
from testimonial_app.models import Testimonial
# Register your models here.
admin.site.register(Testimonial)